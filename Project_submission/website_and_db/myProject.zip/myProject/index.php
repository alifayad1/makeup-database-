<html>
<head>
<title></title>
<style>
#apDiv13 {
	position: absolute;
	width: 630px;
	height: 320px;
	z-index: 6;
	left: 190px;
	top: 250px;
	font-size: 18px;
	background-color:#2e3196;
	border: 3px solid #033;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv14 {
	position: absolute;
	width: 1069px;
	height: 133px;
	z-index: 7;
	left: 0px;
	top: 1063px;
	background-color: #FFFFFF;
}
#apDiv15 {
	position: absolute;
	width: 207px;
	height: 54px;
	z-index: 1;
	left: -25px;
	top: -66px;
	font-size: 36px;
	color: #000;
}
#apDiv1 #apDiv13 div p {
	text-align: justify;
}
#apDiv1 #apDiv13 div {
	color: white;
}
#apDiv17 {
	position: absolute;
	width: 600px;
	height: 663px;
	z-index: 1;
	left: 13px;
	top: 13px;
}
</style>
</head>
<body vlink="#FFFFFF" >
<div id="apDiv1">
  <?php include('header.html'); ?>
  <div id="apDiv13">
    <div id="apDiv17">
      <div align="center"><p><div align="center" style="color:white; font-weight:bold; font-size:36px;">About us</div></p><hr color=yellow >
        <p>Ali Fayad - Mohammad Hoteit - Rami Hoteit - Yehia Farhat</p>
      </div>
	  <div align="center"><p><div align="center" style="color:white; font-weight:bold; font-size:36px;">Our Project</div></p><hr color=yellow>
        <p>This is our website interface for the cmps 277 project</p>
      </div>
    </div>
  </div>
</div>
</body>
</html>
