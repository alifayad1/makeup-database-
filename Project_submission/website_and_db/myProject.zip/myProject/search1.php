<html>
<head>
<title></title>
<style>
#apDiv16 {
	position: absolute;
	width: 433px;
	height: 54px;
	z-index: 11;
	left: 318px;
	top: 475px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv16 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
.search{
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid black;
}
#apDiv17 {
	position: absolute;
	width: 792px;
	height: 400px;
	z-index: 12;
	left: 140px;
	top: 250px;
	border: 3px solid black;
	background-color: gray;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
	padding: 10px;
	padding-right: 30px;
	overflow:hidden;
    overflow-y: scroll;
}
#apDiv17 tr td{
	background-color: white;
	border: 1px solid black;
	text-align: center;
}
#apDiv17 tr th{
	background-color: #2e3196;
	color: white;
	border: 1px solid black;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
<?php include('header.html'); ?>
<div id="apDiv17">
<table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Product Name</th>
		<th height="44">Serial Number</th>
        <th height="44">Price</th>
        <th height="44">Category Serial Number</th>
        <th height="44">Brand Serial Number</th>
		<th height="44">Supplier Serial Number</th>
      </tr>
      <tr>
       <?php
		$s =$_POST['supplier'];
		$c =$_POST['category'];
		$b =$_POST['brand'];
		$querySelect="select * from makeup_product where Category_SerialNum='$c'and Brand_SerialNum='$b' and Supplier_ID='$s'";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td>".$row[5]."</td>";
				print "<td>".$row[6]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
</div>
</div>
</body>
</html>
