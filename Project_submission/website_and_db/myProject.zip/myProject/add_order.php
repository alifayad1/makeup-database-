<html>
<head>
<title></title>
<style>
#apDiv7 {
	position: absolute;
	width: 606px;
	height: 400px;
	z-index: 8;
	left: 244px;
	top: 291px;
	border: 3px solid #033;
	background-color: #2e3196;
	border-radius:7px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv7 td{
	color: white;
	font-size:16px;
}
.title div{
	font-size:24px;
	font-weight: bold;
}
#apDiv7 tr input[type="text"] {
width: 185px;
padding: 3px 6px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
-o-border-radius: 4px;
border-radius: 4px;
}
#apDiv7 tr input[type="password"] {
width: 185px;
padding: 3px 6px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
-o-border-radius: 4px;
border-radius: 4px;
}
#apDiv7 tr input[type="text"]:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr input[type="text"]:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 tr input[type="password"]:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr input[type="password"]:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 tr textarea:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr textarea:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 textarea{
	width: 185px;
	padding: 3px 6px;
	font-size:16px;
	color: #666;
	border: none;
	background-image: -webkit-gradient(linear, »
	0% 0%, 0% 12%, from(#999), to(#fff));
	background-image: -moz-linear-gradient(0% 12% »
	90deg, #fff, #999);
	background-color: #fff;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-o-border-radius: 4px;
	border-radius: 4px;
}
#button {
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid white;
}
#button2 {
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: orange;
	border: 2px solid white;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
  <?php include('header.html'); ?>
  
<div id="apDiv7">
  <form action="add_order1.php" method="post" enctype="multipart/form-data" name="form"">
    <table width="619" height="300" border="0">
      <tr>
        <td colspan="3" class="title"><div align="center">Add Order</div><hr size="3px" color=gray></td>
      </tr>
      <tr>
        <td width="294" height="39" align="center"><div align="right">Order Num</div></td>
        <td width="18">&nbsp;</td>
        <td width="293"><label for="o_number"></label>
          <input type="number" name="o_number" required placeholder="Order Number"></td>
      </tr>
      <tr>
        <td height="48" align="center"><div align="right">Date Ordered</div></td>
        <td>&nbsp;</td>
        <td><label for="date1"></label>
          <input type="date" name="date1" placeholder="Date Ordered"></td>
      </tr>
	  <tr>
        <td height="48" align="center"><div align="right">Expected Recieve Date</div></td>
        <td>&nbsp;</td>
        <td><label for="date2"></label>
          <input type="date" name="date2" placeholder="Expected Recieve Date"></td>
      </tr>
	  <tr>
	  <tr>
          <td width="208" height="34"><div align="right">Customer ID</div></td>
          <td width="23">&nbsp;</td>
          <td width="227"><label for="email"></label>
            <label for="id"></label>
            <div class="select-style"><select name="id" size="1" id="id">
            <option value="None">Choose Customer ID</option>
            <?php 
			$querySelect = "select * from Customer";
								
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				print( "<p>Could not execute query!</p>" );
				die( mysqli_error() . "</body></html>" );
			}
			while ( $row = mysqli_fetch_row($result )) {
					print "<option value='".$row[0]."'>".$row[0]." - ".$row[1]."</option>";
			}
			?>
          </select></div></td>
        </tr>
		<tr>
          <td width="208" height="34"><div align="right">Payment ID</div></td>
          <td width="23">&nbsp;</td>
          <td width="227"><label for="email"></label>
            <label for="id"></label>
            <div class="select-style"><select name="pid" size="1" id="id">
            <option value="None">Choose Payment ID</option>
            <?php 
			$querySelect = "select * from Payment";
								
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				print( "<p>Could not execute query!</p>" );
				die( mysqli_error() . "</body></html>" );
			}
			while ( $row = mysqli_fetch_row($result )) {
					print "<option value='".$row[0]."'>".$row[0]." - ".$row[3]."</option>";
			}
			?>
          </select></div></td>
        </tr>
      <tr>
        <td colspan="3"height="48" align="center" style="font-size:18px; font-weight:bold;"><div align="center">
          <input type="submit" name="button" id="button" value="Add">
          <input type="reset" name="button2" id="button2" value="Reset">
        </div></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
    </table>
  </form>
</div>
</div>
</body>
</html>
