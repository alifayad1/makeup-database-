<html>
<head>
<title></title>
<style>
#apDiv16 {
	position: absolute;
	width: 800px;
	height: 210px;
	z-index: 11;
	left: 118px;
	top: 200px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv16 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
#apDiv17 {
	position: absolute;
	width: 800px;
	height: 180px;
	z-index: 11;
	left: 118px;
	top: 450px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv17 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
#apDiv18 {
	position: absolute;
	width: 800px;
	height: 170px;
	z-index: 11;
	left: 118px;
	top: 670px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv18 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
#apDiv19 {
	position: absolute;
	width: 800px;
	height: 170px;
	z-index: 11;
	left: 118px;
	top: 880px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv19 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
#apDiv21 {
	position: absolute;
	width: 800px;
	height: 170px;
	z-index: 11;
	left: 118px;
	top: 1090px;
	border: 3px solid black;
	background: gray;
	border-radius: 30px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv1 #apDiv21 form table tr td select {
	width: 195px;
padding: 2px 5px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
}
.search{
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid black;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
  <?php include('header.html'); ?>
<div id="apDiv16">
<p>Note: In each listBox(filter) a query is used to get data. ex, Select Brand: "select BrandSerialNum from orders"</p>
<hr>
 <p>Search Makeup Product by Category, Brand, and Supplier</p>
 <hr>
 <p>"select * from makeup_product where Category_SerialNum='$c'and Brand_SerialNum='$b' and Supplier_ID='$s'"</p>
  <form name="form1" method="post" action="search1.php">
    <table width="424" height="47" border="0">
      <tr>
        <td width="200"><div align="right">
          <input type="submit" name="submit" id="submit" value="Search Product" class="search">
        </div></td>
        <td width="63">&nbsp;</td>
        <td width="242"><label for="frm1"></label>
          <div class="select-style"><select name="brand" size="1" id="frm1">
          <option value="">Select Brand</option>
          <?php 
			$querySelect="select * from brand";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td><td>
		  <div class="select-style"><select name="category" size="1" id="frm1">
          <option value="">Select Category</option>
          <?php 
			$querySelect="select * from Category";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td><td>
		  <div class="select-style"><select name="supplier" size="1" id="frm1">
          <option value="">Select Supplier</option>
          <?php 
			$querySelect="select * from supplier";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td>
      </tr>
    </table>
  </form>
</div><div id="apDiv17">
 <p>Search Order by Customer, Payment Num, and Makeup Product</p>
 <hr>
 <p>"select * from orders, order_details where OrderNum = Order_Num and Payment_Num='$d'and Customer_ID='$c' and MakeupProduct_id='$p'"</p>
  <form name="form1" method="post" action="search2.php">
    <table width="424" height="47" border="0">
      <tr>
        <td width="200"><div align="right">
          <input type="submit" name="submit" id="submit" value="Search Order" class="search">
        </div></td>
        <td width="63">&nbsp;</td>
        <td width="242"><label for="frm1"></label>
          <div class="select-style"><select name="c" size="1" id="frm1">
          <option value="">Select Customer</option>
          <?php 
			$querySelect="select * from customer";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[0]."-".$row[1]." ".$row[2]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td><td>
		  <div class="select-style"><select name="d" size="1" id="frm1">
          <option value="">Select Payment</option>
          <?php 
			$querySelect="select * from payment";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[0]." - ".$row[3]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td><td>
		  <div class="select-style"><select name="p" size="1" id="frm1">
          <option value="">Select Product</option>
          <?php 
			$querySelect="select ProductID, Name from makeup_product";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td>
      </tr>
    </table>
  </form>
</div>
<div id="apDiv18">
 <p>Search Customers who bought this Product</p>
 <hr>
 <p>"select * from customer , orders, order_details where Customer_ID = CustomerID and OrderNum = Order_Num and MakeupProduct_id='$p'"</p>
  <form name="form1" method="post" action="search3.php">
    <table width="424" height="47" border="0">
      <tr>
        <td width="200"><div align="right">
          <input type="submit" name="submit" id="submit" value="Search Customer" class="search">
        </div></td>
        <td width="63">&nbsp;</td>
        <td width="242"><label for="frm1"></label>
          <div class="select-style"><select name="p" size="1" id="frm1">
          <option value="">Select Product</option>
          <?php 
			$querySelect="select * from makeup_product";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td>
      </tr>
    </table>
  </form>
</div>
<div id="apDiv19">
 <p>Search Products that were shipped to this address</p>
 <hr>
 <p>"select * from makeup_product, customer , orders, order_details where 	MakeupProduct_id = ProductID and Customer_ID = CustomerID and OrderNum = Order_Num and Shipping_Address='$a'"</p>
  <form name="form1" method="post" action="search4.php">
    <table width="424" height="47" border="0">
      <tr>
        <td width="200"><div align="right">
          <input type="submit" name="submit" id="submit" value="Search Product" class="search">
        </div></td>
        <td width="63">&nbsp;</td>
        <td width="242"><label for="frm1"></label>
          <div class="select-style"><select name="address" size="1" id="frm1">
          <option value="">Select Address</option>
          <?php 
			$querySelect="select distinct Shipping_Address from customer";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[0]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td>
      </tr>
    </table>
  </form>
</div>
<div id="apDiv21">
 <p>Search Customers who have used this discount</p>
 <hr>
 <p>"select * from customer, orders where Customer_ID = CustomerID and OrderNum='$d'"</p>
  <form name="form1" method="post" action="search5.php">
    <table width="424" height="47" border="0">
      <tr>
        <td width="200"><div align="right">
          <input type="submit" name="submit" id="submit" value="Search Customer" class="search">
        </div></td>
        <td width="63">&nbsp;</td>
        <td width="242"><label for="frm1"></label>
          <div class="select-style"><select name="dis" size="1" id="frm1">
          <option value="">Select Discount</option>
          <?php 
			$querySelect="select * from discount";
			if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
			if($result)
			{
				while($row = mysqli_fetch_row($result ))
				{
					print "<option value='".$row[0]."'>".$row[1]." - ".$row[2]."</option>";
				}
			}
			else
			{
				print mysql_error();
			}
			?>
          </select></div></td>
      </tr>
    </table>
  </form>
</div>
</div>
</body>
</html>
