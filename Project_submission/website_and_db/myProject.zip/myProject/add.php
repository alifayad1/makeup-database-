<html>
<head>
<title></title>
<style>
#apDiv16 {
	position: absolute;
	width: 700px;
	height: 100px;
	z-index: 11;
	left: 118px;
	top: 275px;
}
.search{
	padding: 10 15 10 15;
	font-weight: bold;
	background-color: #00FF00;
	font-size: 20px;
	border: 2px solid black;
}
.search:hover{
	background-color: #FF0000;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
  <?php include('header.html'); ?>
<div id="apDiv16">
  <form name="form1" method="post" action="add_brand.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Brand" class="search">
        </div></td>
      </tr>
    </table>
	</form>
	
	<form name="form1" method="post" action="add_category.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Category" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
  <form name="form1" method="post" action="add_customer.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Customer" class="search">
        </div></td>
      </tr>
    </table>
	</form>
	
	<form name="form1" method="post" action="add_product.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Makeup Product" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
  <form name="form1" method="post" action="add_supplier.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Supplier" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
  <form name="form1" method="post" action="add_payment.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Payment" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
    <form name="form1" method="post" action="add_order.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Order" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
  <form name="form1" method="post" action="add_orderd.php">
    <table width="800" height="47" border="0">
      <tr>
        <td width="200"><div align="center">
          <input type="submit" name="submit" id="submit" value="Add Order Details" class="search">
        </div></td>
      </tr>
    </table>
  </form>
  
  </div>
</div>
</body>
</html>
