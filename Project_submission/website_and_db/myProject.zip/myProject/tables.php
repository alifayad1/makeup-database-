<html>
<head>
<title></title>
<style>
#apDiv17 {
	position: absolute;
	width: 792px;
	height: 1000px;
	z-index: 12;
	left: 140px;
	top: 250px;
	border: 3px solid black;
	background-color: gray;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
	padding: 10px;
	padding-right: 30px;
	overflow:hidden;
    overflow-y: scroll;
}
#apDiv17 tr td{
	background-color: white;
	border: 1px solid black;
	text-align: center;
}
#apDiv17 tr th{
	background-color: #2e3196;
	color: white;
	border: 1px solid black;
}
.edit a{
	padding: 2 5 2 5;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid white;
	color: black;
}
.delete a {
	padding: 2 5 2 5;
	font-weight: bold;
	background-color: red;
	border: 2px solid white;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
<?php include('header.html'); ?>
<div id="apDiv17">
<table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Customer ID</th>
		<th height="44">Fname</th>
        <th height="44">LName</th>
        <th height="44">Gender</th>
		<th height="44">DOB</th>
        <th height="44">Email</th>
		<th height="44">Shiiping Address</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Customer";
		$querySelect="select * from customer";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td>".$row[5]."</td>";
				print "<td>".$row[6]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_customer.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_customer.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Supplier ID</th>
		<th height="44">Company Name</th>
        <th height="44">Email</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Supplier";
		$querySelect="select * from supplier";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_supplier.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_supplier.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Brand SerialNum</th>
		<th height="44">Brand Name</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Brand";
		$querySelect="select * from brand";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_brand.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_brand.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">SerialNum</th>
		<th height="44">Type</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Category";
		$querySelect="select * from category";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_category.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_category.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Product Name</th>
		<th height="44">Serial Number</th>
        <th height="44">Price</th>
        <th height="44">Category Serial Number</th>
        <th height="44">Brand Serial Number</th>
		<th height="44">Supplier Serial Number</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Makeup Product";
		$querySelect="select * from makeup_product";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td>".$row[5]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_product.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_product.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Payment Num</th>
		<th height="44">Status</th>
        <th height="44">Amount Paid</th>
        <th height="44">Credit Card Type</th>
        <th height="44">Credit Card Num</th>
		<th height="44">Customer ID</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Payments";
		$querySelect="select * from payment";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td>".$row[5]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_payment.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_payment.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Order Num</th>
		<th height="44">Date Ordered</th>
        <th height="44">Expected Recieve Date</th>
        <th height="44">Customer ID</th>
        <th height="44">Payment Num</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Orders";
		$querySelect="select * from orders";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_order.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_order.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Detail Num</th>
		<th height="44">Date Shipped</th>
        <th height="44">Price</th>
        <th height="44">Makeup Product ID</th>
        <th height="44">Order Num</th>
		<th colspan="2" height="44">Modify</th>
      </tr>
      <tr>
       <?php
		echo "Order Details";
		$querySelect="select * from order_details";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "<td align='center' class='edit'>";
				print "<a href='edit_orderd.php?hid=".$row[0]."'>Edit</a>";
				print "</td>";
				print "<td align='center' class='delete'>";
				print "<a href='delete_orderd.php?hid=".$row[0]."'>Delete</a>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Cart Num</th>
		<th height="44">Product ID</th>
        <th height="44">Qty</th>
        <th height="44">Date</th>
      </tr>
      <tr>
       <?php
		echo "Add_Product";
		$querySelect="select * from add_product";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Order Num</th>
		<th height="44">Discount Num</th>
        <th height="44">Discount Name</th>
        <th height="44">Discount Amount</th>
      </tr>
      <tr>
       <?php
		echo "Discount";
		$querySelect="select * from discount";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
   <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Order Num</th>
		<th height="44">Specail Price</th>
      </tr>
      <tr>
       <?php
		echo "In_Bulk";
		$querySelect="select * from in_bulk";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Order Num</th>
		<th height="44">Cart Num</th>
      </tr>
      <tr>
       <?php
		echo "Linked";
		$querySelect="select * from linked";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Supplier ID</th>
		<th height="44">Phone Number</th>
      </tr>
      <tr>
       <?php
		echo "Phone Number";
		$querySelect="select * from phonenumber";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
   <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Cart Num</th>
		<th height="44">Customer ID</th>
      </tr>
      <tr>
       <?php
		echo "Shopping Cart";
		$querySelect="select * from phonenumber";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
    <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Order Num</th>
		<th height="44">Name</th>
		<th height="44">Type</th>
		<th height="44">Special Instructions</th>
		<th height="44">Special Price</th>
      </tr>
      <tr>
       <?php
		echo "Special Event Order";
		$querySelect="select * from special_event_order";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "<td>".$row[4]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
</div>

</div>
</body>
</html>
