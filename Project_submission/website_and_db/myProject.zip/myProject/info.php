<html>
<head>
<title></title>
<style>
#apDiv17 {
	position: absolute;
	width: 792px;
	height: 1000px;
	z-index: 12;
	left: 140px;
	top: 250px;
	border: 3px solid black;
	background-color: gray;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
	padding: 10px;
	padding-right: 30px;
	overflow:hidden;
    overflow-y: scroll;
}
#apDiv17 tr td{
	background-color: white;
	border: 1px solid black;
	text-align: center;
}
#apDiv17 tr th{
	background-color: #2e3196;
	color: white;
	border: 1px solid black;
}
.edit a{
	padding: 2 5 2 5;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid white;
	color: black;
}
.delete a {
	padding: 2 5 2 5;
	font-weight: bold;
	background-color: red;
	border: 2px solid white;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
<?php include('header.html'); ?>
<div id="apDiv17">
<table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">Product ID</th>
		<th height="44">Name</th>
      </tr>
      <tr>
       <?php
		echo "--> Display all products that no one bought";
		echo "</br></br>select ProductID, Name
from Makeup_Product
where ProductID not IN (select makeupproduct_ID from Order_Details)";
		$querySelect="select ProductID, Name
					from Makeup_Product
					where ProductID not IN (select makeupproduct_ID from Order_Details)";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">SerialNum</th>
		<th height="44">Type</th>
      </tr>
      <tr>
       <?php
		echo "
--> Display all categories that do not have products<br><br>
select SerialNum, Type
from Category
where SerialNum not IN (select category_SerialNum from Makeup_Product)";
		$querySelect="select SerialNum, Type
from Category
where SerialNum not IN (select category_SerialNum from Makeup_Product)";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">CustomerID</th>
		<th height="44">Fname</th>
        <th height="44">Lname</th>
        <th height="44">CountProducts</th>
      </tr>
      <tr>
       <?php
		echo "--> For each customer display how many product he bought <br><br>
select CustomerID, Fname, Lname, count(*) as CountProducts
from Customer, Orders
where CustomerID = CustomerID
Group by CustomerID, Fname, Lname";
		$querySelect="select CustomerID, Fname, Lname, count(*) as CountProducts
from Customer, Orders
where CustomerID = CustomerID
Group by CustomerID, Fname, Lname";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "<td>".$row[3]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">ProductID</th>
		<th height="44">Name</th>
        <th height="44">CountOrders</th>
      </tr>
      <tr>
       <?php
		echo "--> For product display how many customers bought it , do not display products having less than 2 buyers<br><br>
select ProductID, Name, count(*) as CountOrders
from Makeup_Product, Order_Details
where ProductId = makeupproduct_ID
Group by ProductID, Name
having count(*) >= 2";
		$querySelect="select ProductID, Name, count(*) as CountOrders
from Makeup_Product, Order_Details
where ProductId = makeupproduct_ID
Group by ProductID, Name
having count(*) >= 2";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">SUM(order_details.Price)</th>
		<th height="44">FName</th>
      </tr>
      <tr>
       <?php
		echo "-->display names of customers with the amount they paid in total<br><br>
SELECT SUM(order_details.Price),customer.FName
FROM  orders, linked, `shopping cart`, order_details,Customer
WHERE orders.OrderNum = linked.Order_Num and linked.Cart_Num = `shopping cart`.`CartNum` AND order_details.Order_Num = orders.OrderNum AND orders.Customer_ID = customer.CustomerID
group BY orders.Customer_ID";
		$querySelect="SELECT SUM(order_details.Price),customer.FName
FROM  orders, linked, `shopping cart`, order_details,Customer
WHERE orders.OrderNum = linked.Order_Num and linked.Cart_Num = `shopping cart`.`CartNum` AND order_details.Order_Num = orders.OrderNum AND orders.Customer_ID = customer.CustomerID
group BY orders.Customer_ID";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">CompanyName</th>
		<th height="44">Product Count</th>
      </tr>
      <tr>
       <?php
		echo "
-->display companies with more than 2 or more products<br><br>
SELECT supplier.CompanyName, count(*)
FROM supplier,makeup_product,category
WHERE supplier.SupplierID = makeup_product.Supplier_ID and category.SerialNum = makeup_product.Category_SerialNum 
group BY supplier.SupplierID
HAVING COUNT(*)>=2";
		$querySelect="SELECT supplier.CompanyName, count(*)
FROM supplier,makeup_product,category
WHERE supplier.SupplierID = makeup_product.Supplier_ID and category.SerialNum = makeup_product.Category_SerialNum 
group BY supplier.SupplierID
HAVING COUNT(*)>=2";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
 <table width="792" height="39" cellpadding="1" cellspacing="1">
        <th height="44">FName</th>
		<th height="44">CustomerID</th>
        <th height="44">SpecialInstructions</th>
      </tr>
      <tr>
       <?php
		echo "-->display customer name who ordered a special order and their instructions<br><br>
SELECT customer.FName, customer.CustomerID, special_event_order.SpecialInstructions
FROM special_event_order,orders,linked,Customer,`shopping cart`
WHERE special_event_order.Order_Num = orders.OrderNum  and orders.OrderNum = linked.Order_Num and `shopping cart`.CartNum= linked.Cart_Num AND `shopping cart`.`Customer_ID` = Customer.CustomerID
ORDER BY Customer.FName ASC";
		$querySelect="SELECT customer.FName, customer.CustomerID, special_event_order.SpecialInstructions
FROM special_event_order,orders,linked,Customer,`shopping cart`
WHERE special_event_order.Order_Num = orders.OrderNum  and orders.OrderNum = linked.Order_Num and `shopping cart`.CartNum= linked.Cart_Num AND `shopping cart`.`Customer_ID` = Customer.CustomerID
ORDER BY Customer.FName ASC";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
				die( "Could not connect to database </body></html>" );

			if ( !mysqli_select_db( $database, "mydb" ) )
				 die( "Could not open database </body></html>" );

			if ( !( $result = mysqli_query( $database, $querySelect ) ) )  {
				  print( "<p>Could not execute query!</p>" );
				  die( mysqli_error() . "</body></html>" );
			}
		if($result)
		{
			while($row = mysqli_fetch_row($result ))
			{
				print "<tr height='39'>";
				print "<td>".$row[0]."</td>";
				print "<td>".$row[1]."</td>";
				print "<td>".$row[2]."</td>";
				print "</tr>";
			}
		}
		?>
        </tr>
 </table>
 
  
 
</div>

</div>
</body>
</html>
