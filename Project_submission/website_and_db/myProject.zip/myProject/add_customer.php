<html>
<head>
<title></title>
<style>
#apDiv7 {
	position: absolute;
	width: 606px;
	height: 550px;
	z-index: 8;
	left: 244px;
	top: 291px;
	border: 3px solid #033;
	background-color: #2e3196;
	border-radius:7px;
	box-shadow: 6px 6px 20px rgba(0, 0, 0, 1);
}
#apDiv7 td{
	color: white;
	font-size:16px;
}
.title div{
	font-size:24px;
	font-weight: bold;
}
#apDiv7 tr input[type="text"] {
width: 185px;
padding: 3px 6px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
-o-border-radius: 4px;
border-radius: 4px;
}
#apDiv7 tr input[type="password"] {
width: 185px;
padding: 3px 6px;
font-size:16px;
color: #666;
border: none;
background-image: -webkit-gradient(linear, »
0% 0%, 0% 12%, from(#999), to(#fff));
background-image: -moz-linear-gradient(0% 12% »
90deg, #fff, #999);
background-color: #fff;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
-o-border-radius: 4px;
border-radius: 4px;
}
#apDiv7 tr input[type="text"]:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr input[type="text"]:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 tr input[type="password"]:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr input[type="password"]:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 tr textarea:focus{
	-webkit-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	-moz-box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
	box-shadow: 0 0 12px rgba(51, 204, 255, 1.2);
}
#apDiv7 tr textarea:focus {
	-moz-animation-name: pulse;
	-moz-animation-duration: 1.5s;
	-moz-animation-iteration-count: infinite;
	-moz-animation-timing-function: ease-in-out;
}
#apDiv7 textarea{
	width: 185px;
	padding: 3px 6px;
	font-size:16px;
	color: #666;
	border: none;
	background-image: -webkit-gradient(linear, »
	0% 0%, 0% 12%, from(#999), to(#fff));
	background-image: -moz-linear-gradient(0% 12% »
	90deg, #fff, #999);
	background-color: #fff;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-o-border-radius: 4px;
	border-radius: 4px;
}
#button {
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: #00FF00;
	border: 2px solid white;
}
#button2 {
	padding: 5 10 5 10;
	font-weight: bold;
	background-color: orange;
	border: 2px solid white;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
  <?php include('header.html'); ?>
  
<div id="apDiv7">
  <form action="add_customer1.php" method="post" enctype="multipart/form-data" name="form"">
    <table width="619" height="200" border="0">
      <tr>
        <td colspan="3" class="title"><div align="center">Add Customer</div><hr size="3px" color=gray></td>
      </tr>
      <tr>
        <td width="294" height="39" align="center"><div align="right">Serial Number</div></td>
        <td width="18">&nbsp;</td>
        <td width="293"><label for="c_number"></label>
          <input type="number" name="c_number" required placeholder="Serial Number"></td>
      </tr>
      <tr>
        <td height="48" align="center"><div align="right">FName</div></td>
        <td>&nbsp;</td>
        <td><label for="fname"></label>
          <input type="text" name="fname" placeholder="FName"></td>
      </tr>
	  <tr>
        <td height="48" align="center"><div align="right">LName</div></td>
        <td>&nbsp;</td>
        <td><label for="lname"></label>
          <input type="text" name="lname" placeholder="LName"></td>
      </tr>
	   <tr>
        <td height="34" align="center""><div align="right">Gender</div></td>
        <td>&nbsp;</td>
        <td><input type="radio" name="gender" id="radio" value="Male">
          <label for="radio"></label>
          Male 
          <input type="radio" name="gender" id="radio2" value="Female">
          <label for="radio2"></label>
          Female</td>
      </tr>
	  <tr>
        <td height="48" align="center"><div align="right">DOB</div></td>
        <td>&nbsp;</td>
        <td><label for="date"></label>
          <input type="date" name="date" placeholder="Type"></td>
      </tr>
	  <tr>
        <td height="48" align="center"><div align="right">Email</div></td>
        <td>&nbsp;</td>
        <td><label for="email"></label>
          <input type="text" name="email" placeholder="Type"></td>
      </tr>
	  <tr>
        <td height="48" align="center"><div align="right">Shipping Address</div></td>
        <td>&nbsp;</td>
        <td><label for="address"></label>
          <input type="text" name="address" placeholder="address"></td>
      </tr>
      <tr>
        <td colspan="3"height="48" align="center" style="font-size:18px; font-weight:bold;"><div align="center">
          <input type="submit" name="button" id="button" value="Add">
          <input type="reset" name="button2" id="button2" value="Reset">
        </div></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
    </table>
  </form>
</div>
</div>
</body>
</html>
