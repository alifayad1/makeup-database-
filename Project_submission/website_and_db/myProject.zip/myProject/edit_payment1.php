<html>
<head>
<title></title>
<style>
#apDiv7 {
	position: absolute;
	width: 606px;
	height: 81px;
	z-index: 8;
	left: 248px;
	top: 363px;
	border: 3px solid red;
	background-color: #2e3196;
	color: white;
	font-weight: bold;
	font-size: 25px;
	padding: 5px;
}
</style>
</head>
<body vlink="#FFFFFF">
<div id="apDiv1">
  <?php include('header.html'); ?>
<div id="apDiv7">
  <div align="center">
  <?php
	  	$queryInsert="update payment set Status = '$_POST[status]',AmountPaid='$_POST[amount]',CreditCardType='$_POST[type]',CreditCardNum='$_POST[c_num]',Customer_id='$_POST[id]' where PaymentNum = $_POST[p_number]";
		if ( !( $database = mysqli_connect( "localhost", "root", "" ) ) )
			die( "Could not connect to database </body></html>" );

		if ( !mysqli_select_db( $database, "mydb" ) )
		 die( "Could not open database </body></html>" );
	 
		if ( !( $resultInsert = mysqli_query( $database, $queryInsert ) ) )  {
		  print( "<p>Could not execute query!</p>" );
		  die( mysqli_error() . "</body></html>" );
		}
		
		mysqli_close( $database );
		
		if($resultInsert)
	  	{
	  	  	 print "<span><strong><h2><font style='color:white;'>Payment Updated</font></h2></strong></span>";
      	}
      	else
      	{
			  print mysql_error();
			  
      	}
 
 ?>
  </div>
</div>
</div>
</body>
</html>
